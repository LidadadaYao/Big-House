package com.ly.springboothelloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringbootHellowordApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootHellowordApplication.class, args);
    }
}
